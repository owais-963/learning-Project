package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.println("Student Result");
        int age= 18;
        String name="Owais Ali";
        char Grade='A';
        double GPA= 3.7;
        boolean perfectAtendence=true;

        System.out.println(name);
        System.out.println(age);
        System.out.println(GPA);
        System.out.println(Grade);
        System.out.println(perfectAtendence);
        System.out.println(name.charAt(7));
        System.out.println("Student Name is " +name + " Student GPA is "+GPA);
        System.out.println("Enter the Value");
        Scanner input= new Scanner(System.in);
        int var=input.nextInt();
        System.out.println(var);


	// write your code here
    }
}
